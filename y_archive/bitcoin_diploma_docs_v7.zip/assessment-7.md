# assessment-7.md

# Bitcoin Diploma Assessment Framework

## Purpose

This document defines how learning will be evaluated in the redesigned Bitcoin Diploma.

Plain-language purpose:

How is learning evaluated?

This document should connect learning objectives to evidence of learning.

It does not define learning objectives. See `objectives-7.md`.

It does not define certification requirements. See `certification-7.md`.

It does not define project workstreams or milestones. See `scope-7.md`.

---

# 1. Status

This document is a working framework.

The existing source material identifies the need for assessment alignment, formative assessment, summative assessment, and competency evidence.

Detailed assessment design remains pending.

---

# 2. Assessment Philosophy

Pending.

The available source material indicates that assessment should align with:

- learning objectives;
- competencies;
- learner outcomes.

No final assessment philosophy has been approved.

---

# 3. Assessment Principles

Assessment should be:

- aligned to learning objectives;
- aligned to competencies;
- suitable for beginner learners;
- usable by educators;
- adaptable across delivery contexts where possible.

Pending: final assessment principles require human confirmation.

---

# 4. Formative Assessment

Possible formative evidence identified in the current objectives document includes:

- classroom discussions;
- think-pair-share outputs;
- reflection journals;
- exit tickets;
- activity completion;
- peer feedback;
- concept checks;
- misconception checks.

Pending: final formative assessment tools.

---

# 5. Summative Assessment

Possible summative evidence identified in the current objectives document includes:

- project;
- case study analysis;
- presentation;
- podcast;
- written explanation;
- written exam;
- essay;
- practical demonstration.

Pending: final summative assessment model.

---

# 6. Competency Evidence

Assessment should help identify whether learners can demonstrate the competencies described in `objectives-7.md`.

Competency areas include:

- Monetary Foundations;
- Economic Reasoning;
- Bitcoin Fundamentals;
- Practical Bitcoin Orientation;
- Critical Evaluation;
- Social Learning and Dialogue;
- Local Application.

Pending: competency evidence standards.

---

# 7. Assessment Mapping

The assessment system should eventually map:

```text
Objective
↓
Competency
↓
Evidence
↓
Assessment
```

Pending: full assessment map.

---

# 8. Delivery Context Questions

Assessment design should eventually clarify what evidence works across:

- in-person delivery;
- online delivery;
- self-paced delivery;
- hybrid delivery.

Pending: delivery-specific assessment guidance.

---

# 9. Assessment Gaps To Resolve

The following gaps remain:

- assessments need to be mapped to competencies;
- competency evidence needs to be defined;
- formative assessment tools need to be selected or created;
- summative assessment expectations need to be clarified;
- online and self-paced checkpoint mechanisms need stronger design;
- assessment should be aligned with but separated from certification.

---

# 10. Relationship To Other Documents

Use `objectives-7.md` for learning objectives and competencies.

Use `certification-7.md` for certification questions.

Use `scope-7.md` for the workstream that creates the assessment framework.
