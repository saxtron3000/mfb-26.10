# objectives-7.md

# Bitcoin Diploma Learning Objectives

## Purpose

This document defines the learning architecture of the redesigned Bitcoin Diploma.

It answers:

- What should learners know?
- What should learners understand?
- What should learners be able to do?
- What competencies should the Diploma develop?
- What graduate profile should the Diploma work toward?

This document does not define project workstreams, milestones, broad design philosophy, assessment methods, or certification requirements.

For assessment, see `assessment-7.md`.

For certification, see `certification-7.md`.

For workstreams and deliverables, see `scope-7.md`.

---

# 1. Status

These objectives are a working framework.

They should be refined after:

- final module structure is confirmed;
- Core / Nice-to-Have / Advanced boundaries are agreed;
- research findings are reviewed;
- assessment expectations are clarified in `assessment-7.md`.

---

# 2. Objective Design Principles

Learning objectives should be:

- precise;
- measurable;
- beginner-appropriate;
- aligned to competencies;
- aligned to activities;
- suitable for educator delivery;
- clear about core, optional, and advanced expectations;
- supportive of critical thinking;
- practical where skill acquisition is required.

Assessment alignment is handled in `assessment-7.md`.

Certification alignment is handled in `certification-7.md`.

---

# 3. Graduate Profile

The redesign should define what a graduate of the Bitcoin Diploma looks like.

A graduate should have developed:

## Knowledge

A beginner-appropriate understanding of money, Bitcoin, trade-offs, custody, and monetary systems.

## Competence

The ability to discuss Bitcoin clearly, evaluate claims, understand basic practical pathways, and take informed next steps.

## Reasoning

The ability to reason from first principles rather than repeat conclusions.

## Confidence

The confidence to ask better questions, continue learning, and avoid obvious mistakes.

## Participation

The ability to participate meaningfully in local Bitcoin education, discussion, and community learning.

Pending: final graduate profile wording requires human confirmation.

---

# 4. Program-Level Learning Aim

Learners should develop the knowledge, reasoning, confidence, and beginner-appropriate practical orientation needed to understand Bitcoin from first principles, discuss money and Bitcoin critically, and take informed next steps in real-world Bitcoin learning or usage.

---

# 5. Learning Domains

## 5.1 Knowledge

Learners should know beginner-appropriate concepts related to:

- money;
- value;
- scarcity;
- trade;
- functions of money;
- properties of money;
- fiat systems;
- Bitcoin;
- basic custody concepts;
- on-chain and Lightning distinctions;
- risks, criticisms, and limitations.

Advanced technical concepts should be marked as optional or advanced unless required for beginner competence.

## 5.2 Understanding

Learners should understand:

- why money exists;
- how monetary systems shape behavior;
- how different monetary systems compare;
- why Bitcoin matters to different people and communities;
- how practical Bitcoin use differs from advanced technical theory;
- why self-custody matters and what barriers learners may face;
- the difference between on-chain and Lightning use;
- how economic, technical, social, and philosophical themes interact.

## 5.3 Skills

Learners should be able to:

- explain key ideas in their own words;
- compare monetary systems;
- analyze real-world scenarios using economic reasoning;
- discuss Bitcoin using evidence and reasoning;
- identify trade-offs;
- participate in structured dialogue;
- reflect on personal and community relevance;
- complete beginner-appropriate practical learning tasks where included;
- evaluate claims, criticisms, benefits, and limitations.

## 5.4 Attitudes and Dispositions

Learners should develop:

- agency;
- curiosity;
- confidence;
- independent reasoning;
- willingness to ask questions;
- ability to learn socially;
- respect for local context;
- caution around security and custody;
- seriousness about money, technology, and responsibility.

---

# 6. Draft Program-Level Objectives

By the end of the redesigned Bitcoin Diploma, learners should be able to:

1. Define foundational monetary concepts using clear language.
2. Explain why money exists and what problems it helps solve.
3. Identify the functions and properties of money.
4. Compare different monetary systems and instruments.
5. Explain the basic purpose of Bitcoin from first principles.
6. Distinguish practical Bitcoin usage from advanced technical theory.
7. Analyze trade-offs involved in Bitcoin use, custody, and payment methods.
8. Discuss Bitcoin’s benefits, risks, criticisms, and limitations using reasoned arguments.
9. Apply economic reasoning to real-world examples.
10. Demonstrate beginner-appropriate practical competence where practical activities are included.
11. Participate in structured discussions and collaborative learning.
12. Reflect on how Bitcoin education connects to personal agency, community context, and local conditions.

---

# 7. Draft Competency Areas

## 7.1 Monetary Foundations

Learners can explain what money is, why it exists, and what makes money useful.

## 7.2 Economic Reasoning

Learners can use concepts such as scarcity, value, incentives, and trade-offs to analyze real situations.

## 7.3 Bitcoin Fundamentals

Learners can explain Bitcoin’s basic purpose, design rationale, and role as a monetary technology.

## 7.4 Practical Bitcoin Orientation

Learners can identify realistic beginner actions and safety considerations when approaching Bitcoin use.

## 7.5 Critical Evaluation

Learners can assess claims about Bitcoin, including benefits, criticisms, and limitations.

## 7.6 Social Learning and Dialogue

Learners can participate in structured discussion, listen to others, explain reasoning, and revise ideas.

## 7.7 Local Application

Learners can connect Bitcoin concepts to local economic, social, and cultural context.

Assessment evidence for these competencies belongs in `assessment-7.md`.

---

# 8. Bloom’s Taxonomy Reference

The objectives should use appropriate cognitive levels.

## Remember

Define key concepts.

## Understand

Explain functions, systems, and relationships.

## Apply

Use economic reasoning in real scenarios.

## Analyze

Compare systems and trade-offs.

## Evaluate

Assess claims, risks, benefits, and limitations.

## Create

Designing new systems or solutions may be optional or advanced unless confirmed as a core outcome.

---

# 9. Objective Gaps To Resolve

The following gaps must be resolved before objectives are considered final:

- objectives need to be made consistently measurable;
- competencies need to be mapped to modules;
- practical skills need to be structured through PPP where applicable;
- beginner technical prerequisites need clarification;
- Core / Nice-to-Have / Advanced outcomes need definition;
- online and self-paced learning expectations need stronger definition.

Assessment gaps belong in `assessment-7.md`.

Certification gaps belong in `certification-7.md`.

---

# 10. Working Template For Module-Level Objectives

## Module Title

### Core Idea

One-sentence summary.

### Knowledge Objectives

Learners should know:

- [concept]
- [concept]

### Understanding Objectives

Learners should understand:

- [principle]
- [relationship]
- [trade-off]

### Competency Objectives

Learners should be able to:

- [measurable action]
- [measurable action]

### Practical Competence

Learners should be able to:

- [practical action, if applicable]

### Discussion Competence

Learners should be able to:

- [discussion behavior]
- [reasoning behavior]

### Review Point

Learners should revisit:

- [key concept]
- [previous module connection]

### Optional / Advanced

Optional or advanced outcomes:

- [advanced item]
- [extension item]

### Out of Scope

This module does not require learners to:

- [non-essential item]
- [advanced technical item]

---

# 11. Relationship To Other Documents

Use `review-7.md` for current weaknesses in the existing Diploma.

Use `research-7.md` to validate objective decisions.

Use `design-7.md` for principles and constraints.

Use `assessment-7.md` for evidence of learning and assessment methods.

Use `certification-7.md` for certification questions.

Use `scope-7.md` for the work required to finalize and implement objectives.
