# scope-7.md

# Bitcoin Diploma Redesign Scope of Work & Milestones

## Purpose

This document defines the work required to complete the Bitcoin Diploma redesign.

It answers:

- What work must be completed?
- What deliverables are required?
- What milestones must be achieved?
- What is included in the redesign project?
- What is excluded from the redesign project?
- What does completion look like?

This document does not diagnose the current Diploma. See `review-7.md`.

This document does not define design philosophy or decision-making principles. See `design-7.md`.

This document does not define learning objectives. See `objectives-7.md`.

This document does not define assessment methodology. See `assessment-7.md`.

This document does not define certification requirements. See `certification-7.md`.

---

# Executive Summary

The Bitcoin Diploma redesign seeks to improve:

- completion rates;
- educational impact;
- practical competence;
- educator usability;
- consistency of delivery;
- scalability;
- long-term maintainability.

The redesign is not intended to replace the identity, philosophy, or purpose of the Diploma.

---

# Project Assumptions

The scope assumes the current working design direction described in `design-7.md`.

The following assumptions affect project execution:

- Target duration: maximum 8 hours.
- Working architecture: 4 modules of approximately 2 hours.
- In-person first.
- Single Diploma with optional advanced sections.
- Core / Nice-to-Have / Advanced categorization.
- Assessment framework is in scope.
- Certification design is out of scope.
- Localization preparation is in scope.
- Localization implementation is out of scope.
- Publishing is part of project completion.

---

# Workstreams

## 1. Curriculum Architecture

### Purpose

Reduce duration, duplication, and cognitive load while improving clarity and retention.

### Deliverables

- Four-module architecture proposal
- Core content map
- Nice-to-Have content map
- Advanced content map
- Revised sequencing
- Content reduction recommendations

---

## 2. Learning Outcomes Framework

### Purpose

Create measurable learning expectations.

### Deliverables

- Knowledge objectives
- Competency objectives
- Outcome objectives

---

## 3. Competency Mapping System

### Purpose

Create explicit links between:

- objectives;
- competencies;
- activities;
- assessment;
- learner outcomes.

### Deliverables

- Competency framework
- Competency-to-module map
- Competency-to-activity map
- Competency evidence framework

---

## 4. Practical Learning Redesign

### Purpose

Increase active participation and practical competence.

### Deliverables

- Practical skills map
- PPP implementation framework
- Real-world scenarios
- Guided application activities
- Practical exercises

---

## 5. Activity Bank

### Purpose

Improve participation and engagement.

### Deliverables

- Embedded Activity Bank version
- Standalone Activity Bank version
- Objective mapping

---

## 6. Educator Guide Redesign

### Purpose

Transform the Educator Guide into an essential implementation tool.

### Deliverables

- Facilitation guidance
- Timing guidance
- Discussion prompts
- Activity procedures
- Practical lesson procedures
- Review procedures
- Assessment guidance
- Classroom management guidance
- Online adaptations

---

## 7. Review & Consolidation System

### Purpose

Improve retention and transfer of learning.

### Deliverables

- Knowledge review
- Reflection
- Skills check
- Competency check

---

## 8. Scope Rationalization & Content Reduction

### Purpose

Reduce unnecessary cognitive load.

### Deliverables

- Content audit
- Duplicate content audit
- Essential vs Optional classification
- Beginner prerequisite analysis
- Content reduction recommendations

---

## 9. Advanced Learning Pathway

### Purpose

Separate advanced learning from beginner learning.

### Deliverables

- Advanced content inventory
- Advanced pathway recommendations
- Technical content recommendations

---

## 10. Assessment Foundation & Assessment Framework

### Purpose

Create the foundation for evaluating learning.

### Deliverables

- Assessment philosophy
- Assessment framework
- Competency evidence framework
- Assessment mapping
- Evidence models

### Note

Certification design is outside the scope of this project.

---

## 11. Measurable Outcomes Framework

### Purpose

Improve the ability to evaluate impact.

### Deliverables

- Outcome framework
- Outcome indicators
- Learning evidence recommendations
- Program impact indicators

---

## 12. Delivery Model Definition

### Purpose

Clarify implementation expectations.

### Deliverables

- In-person delivery specification
- Online adaptation guidance
- Self-paced adaptation guidance
- Delivery assumptions documentation

---

## 13. Timing & Workload Validation

### Purpose

Ensure realistic implementation.

### Deliverables

- Module timing analysis
- Activity timing analysis
- Total workload analysis
- Facilitator implementation guidance

---

## 14. Localization Preparation

### Purpose

Prepare the Diploma for future localization.

### Deliverables

- Localization guidelines
- Adaptable elements map
- Standardized elements map
- Localization opportunities register
- Localization constraints register
- AI localization considerations

### Note

Localization implementation is not included.

---

## 15. Publishing System

### Purpose

Prepare final publication-ready outputs.

### Deliverables

- Student Book PDF
- Educator Guide PDF
- Website publication
- GitHub Markdown source files
- Translation-ready source files

---

# Milestones

## Milestone 1 — Review & Research

- Review completed
- Research framework completed
- Decision gaps identified

## Milestone 2 — Learning Outcomes

- Objectives framework completed
- Competency framework completed

## Milestone 3 — Curriculum Architecture

- Four-module architecture completed
- Content categorization completed

## Milestone 4 — Practical Learning & Activity Bank

- Activity Bank completed
- PPP framework completed

## Milestone 5 — Educator Guide

- Educator Guide redesign completed
- Delivery support systems completed

## Milestone 6 — Assessment Foundation

- Assessment framework completed
- Competency evidence completed

## Milestone 7 — Publishing

- PDFs completed
- Website completed
- GitHub publication completed

## Milestone 8 — Feedback & Iteration

- Feedback report completed
- Revision backlog completed

---

# Definition of Completion

The redesign is complete when:

- Diploma can be delivered within approximately 8 hours.
- Learning outcomes are clearly defined.
- Competencies are mapped to modules, activities, and evidence.
- Practical learning is significantly increased.
- Essential and optional content are clearly separated.
- Advanced content is appropriately separated.
- Timing assumptions are documented.
- Delivery assumptions are documented.
- Assessment framework is completed.
- Measurable outcomes are defined.
- Educator Guide is redesigned.
- Activity Bank is operational.
- Review systems are integrated.
- Student Book is published.
- Educator Guide is published.
- Website version is published.
- GitHub source files are published.
- Translation-ready source files are published.
- Localization preparation is completed.

---

# Out of Scope

The following items are intentionally excluded from the current redesign project:

- Certification design
- Certification standards
- Certification governance
- Full localization implementation
- AI-powered localization systems
- Maintenance of multiple localized curriculum variants

These may become future projects.

---

# Remaining Open Items

- Success Metrics
- North Star Definition
- Certification Design
- AI Localization
- Advanced Pathway Design
