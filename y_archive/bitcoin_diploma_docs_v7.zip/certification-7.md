# certification-7.md

# Bitcoin Diploma Certification Framework

## Purpose

This document collects the certification questions and future certification considerations for the Bitcoin Diploma.

Plain-language purpose:

What qualifies a learner for certification?

Certification design is currently outside the scope of the redesign project.

This document exists to preserve the certification questions separately from learning objectives and assessment.

For learning objectives, see `objectives-7.md`.

For assessment, see `assessment-7.md`.

For project scope, see `scope-7.md`.

---

# 1. Status

Certification design is out of scope for the current redesign project.

The current project may prepare foundations for certification through:

- learning objectives;
- competencies;
- assessment framework;
- evidence models.

The actual certification model will be developed later.

---

# 2. Certification Philosophy

Pending.

No final certification philosophy has been approved.

---

# 3. Certification Alignment

The source material indicates that certification should eventually be aligned with:

- learning outcomes;
- competencies;
- assessment evidence.

Pending: final certification alignment model.

---

# 4. Certification Questions

The following questions were identified in the current objectives document:

- What evidence proves competence?
- Who verifies competence in decentralized teaching environments?
- What is the difference between participation, completion, and certification?
- What must be standardized across communities?
- What can be adapted locally?
- What assessment evidence works for in-person, online, self-paced, and hybrid delivery?

These questions remain unresolved.

---

# 5. Possible Certification Models

Pending.

Potential certification models have not been approved.

Do not fill this section without human decision.

---

# 6. Verification Questions

Pending.

The following areas require future decisions:

- who verifies competence;
- how verification works in decentralized delivery;
- what evidence is acceptable;
- what must be standardized;
- what can vary locally.

---

# 7. Out of Scope For Current Redesign

The current redesign project does not include:

- certification design;
- certification standards;
- certification governance;
- certification verification systems.

These may become future projects.

---

# 8. Relationship To Other Documents

Use `objectives-7.md` for learning objectives and competencies.

Use `assessment-7.md` for evidence of learning and evaluation.

Use `scope-7.md` for the statement that certification design is out of scope.
