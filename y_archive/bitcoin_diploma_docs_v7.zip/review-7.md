# review-7.md

# Bitcoin Diploma Review

## Purpose

This document reviews the existing Bitcoin Diploma.

It identifies:

- what currently works;
- what creates friction;
- what should be preserved;
- what current problems need to be addressed elsewhere in the redesign documentation.

This is a diagnostic document.

It does not define the new design, learning objectives, assessment system, certification model, project scope, milestones, or implementation plan.

For design principles, see `design-7.md`.

For learning outcomes, see `objectives-7.md`.

For assessment, see `assessment-7.md`.

For certification, see `certification-7.md`.

For project workstreams and deliverables, see `scope-7.md`.

---

# 1. Review Summary

The existing Bitcoin Diploma has strong foundations.

Its major strengths are:

- recognizable educational identity;
- accessible messaging;
- serious treatment of Bitcoin;
- grassroots adaptability;
- social learning;
- thematic consistency;
- practical orientation;
- logical progression from foundational concepts toward more advanced ideas.

Its major weaknesses are:

- unclear and excessive duration;
- inconsistent pacing;
- broad and sometimes vague scope;
- weak measurable objectives;
- weak competency mapping;
- insufficient structured review;
- educator support limitations;
- technical overload for beginners in some sections;
- unclear delivery assumptions;
- localization challenges.

The core conclusion:

The Diploma does not primarily suffer from a lack of content. It suffers from weak learning architecture, unclear boundaries, inconsistent timing, and inconsistent educator support.

---

# 2. Strengths

## 2.1 Strong Educational Identity

The Diploma presents a coherent educational worldview.

This creates:

- consistency;
- recognizability;
- memorability;
- narrative cohesion.

The identity of the Diploma is one of its strongest assets.

## 2.2 Accessible Messaging

Complex ideas are generally communicated in accessible language.

Concepts are frequently connected to real-world experiences and situations that learners can relate to.

## 2.3 Conviction

The Diploma treats Bitcoin as a serious subject worthy of study.

It avoids excessive corporate, institutional, or neutral educational language.

This helps differentiate the program from many generic financial literacy courses.

## 2.4 Practical Orientation

The Diploma includes practical pathways into Bitcoin usage and participation.

Learners are not limited to theory.

However, practical content is not yet consistently structured as skill development.

## 2.5 Global and Grassroots Format

The Diploma is adaptable to community-led and grassroots environments.

It does not depend heavily on expensive infrastructure or institutional systems.

This supports:

- independent educators;
- local communities;
- open-source educational use;
- non-institutional delivery.

## 2.6 Social Learning Environment

The Diploma is not designed solely as a self-study resource.

It encourages:

- discussion;
- reflection;
- participation;
- collaborative learning;
- dialogue.

These are significant strengths that contribute to learner engagement.

## 2.7 Thematic Consistency

Thematic consistency exists across chapters.

Ideas are reinforced through recurring themes and conceptual links.

This creates a stronger overall narrative than a disconnected set of lessons.

## 2.8 Logical Progression

The Diploma generally moves from foundational concepts toward more advanced concepts.

This progression supports learner orientation and understanding.

---

# 3. Weaknesses

## 3.1 Duration

Current duration is one of the most significant weaknesses.

Timing expectations are unclear and appear to vary across delivery contexts.

This affects:

- completion;
- pacing;
- student commitment;
- educator planning;
- consistency between cohorts.

## 3.2 Pacing Ambiguity

Some materials appear to imply different session lengths.

Activity timing is not always clearly accounted for.

This makes it difficult for educators to judge what is realistic.

## 3.3 Broad and Vague Scope

The Diploma covers many domains simultaneously:

- economics;
- history;
- technology;
- philosophy;
- practical Bitcoin usage.

This breadth is part of the program’s richness, but it creates scope ambiguity.

## 3.4 Blurred Disciplinary Boundaries

The Diploma frequently moves between:

- economics;
- history;
- technology;
- philosophy;
- practical Bitcoin usage.

The boundaries between these domains are not always clear.

As a result, learners may struggle to distinguish between:

- facts;
- interpretation;
- opinion;
- technical explanation;
- philosophical discussion;
- practical instruction.

## 3.5 Weak Learning Objectives

Some learning objectives are not yet precise or measurable.

This makes it harder to define what learners should know, understand, or be able to do by the end of a section.

## 3.6 Weak Competency Mapping

There is not yet a strong visible relationship between:

- lessons;
- activities;
- competencies;
- learner outcomes.

Assessment evidence is addressed separately in `assessment-7.md`.

## 3.7 Lack of Measurable Outcomes

The current Diploma makes it difficult to determine:

- learner mastery;
- learner progress;
- outcome achievement.

A measurable outcomes framework belongs in `objectives-7.md` and `assessment-7.md`.

## 3.8 Limited Structured Review

Important concepts recur, but review is not always intentional.

Some repetition supports reinforcement, but some repetition appears inefficient.

## 3.9 Educator Support Limitations

The Educator Guide has not consistently provided enough added value beyond the Student Book.

Educators need more support for:

- pacing;
- facilitation;
- questioning;
- activities;
- misconceptions;
- review;
- classroom management;
- adaptation.

The work required to redesign the Educator Guide belongs in `scope-7.md`.

## 3.10 Technical Overload

Some technical content appears to exceed beginner prerequisites.

This may increase cognitive load without proportionate learner benefit.

## 3.11 Delivery Mode Ambiguity

It is not always clear whether the Diploma assumes:

- in-person delivery;
- online delivery;
- self-paced learning;
- hybrid delivery.

Delivery model definition belongs in `scope-7.md`.

## 3.12 Localization Challenges

The Diploma is globally oriented, but some content is not yet easy to adapt to different:

- economies;
- cultures;
- education systems;
- technological contexts.

Localization preparation belongs in `scope-7.md`.

## 3.13 Practical Skill Structure

Practical content exists, but it is not consistently structured as:

- demonstration;
- supported practice;
- independent application.

The practical learning redesign belongs in `scope-7.md`.

---

# 4. Review Conclusions

The existing Diploma should be treated as a strong foundation, not a failed product.

Its value lies in:

- identity;
- accessibility;
- seriousness;
- social learning;
- grassroots adaptability;
- practical orientation;
- conceptual progression.

Its limitations lie in:

- structure;
- pacing;
- measurable objectives;
- competency mapping;
- educator support;
- review systems;
- beginner technical load;
- delivery assumptions.

The redesign process should preserve the strengths while solving the structural and pedagogical weaknesses in the appropriate documents.

---

# 5. Boundaries of This Document

This document intentionally does not include:

- proposed module architecture;
- design philosophy for the new Diploma;
- implementation milestones;
- project workstreams;
- detailed deliverables;
- finalized learning objectives;
- assessment methods;
- certification requirements;
- publishing plans.

Those belong in `design-7.md`, `objectives-7.md`, `assessment-7.md`, `certification-7.md`, and `scope-7.md`.
